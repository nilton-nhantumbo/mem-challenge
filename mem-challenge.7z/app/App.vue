
<template>
  <div id="app" class="container">
        <h1 >Memory Allocationn</h1>
       <ram-view></ram-view>
  </div>
</template>

<script>

export default {
    name: 'app',
}
</script>