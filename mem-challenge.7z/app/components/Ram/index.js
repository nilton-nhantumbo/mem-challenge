import Vue from 'vue'

//Ram Components
Vue.component('ram-view', require('./Ram.component').default);