<template>
<div>
  <p class="pp"> World!</p>
</div>
</template>

<script>

export default {
  data () {
    return {
      greeting: 'Hello'
    }
  }
}
</script>

<style lang="css" scoped>
  p{
  font-size: 4em;
  text-align: center}
</style>